package com.testePratico.testePratico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestePraticoApplicationTests {

	@Test
	void contextLoads() {
	}

}
